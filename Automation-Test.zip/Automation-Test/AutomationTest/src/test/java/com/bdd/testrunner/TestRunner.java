
package com.bdd.testrunner;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src\\test\\resources\\Features.UI_Features", glue = { "com.bdd.hooks",
		"com.bdd.stepdef" }, tags = "@Test")
public class TestRunner extends AbstractTestNGCucumberTests {

}

