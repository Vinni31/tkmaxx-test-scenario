package com.bdd.constants;

public enum Browser {
	CHROME, FIREFOX, EDGE
}
