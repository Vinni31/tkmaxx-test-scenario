# Automation-Test

Run command : mvn clean install -Dbrowser.name=chrome -Durl=QA
Require git to install
  -Install git to clone, create new branch from main, commit changes and push your code
**NOTE: Do not merge your code into main branch**
